# Habla Cards — Android MVP

A small offline-first Spanish speaking flashcard app. The cards are stored in the app; speech recognition uses the Android speech recognition service configured for Spanish (Spain), which may require internet depending on the installed recognition provider. Spanish pronunciation uses Android Text-to-Speech and requires a Spanish voice installed on the device.

## Build an APK with GitHub Actions

1. Create a new empty GitHub repository named `habla-cards`.
2. Upload the contents of this folder to the repository (keep the `.github` folder).
3. Open **Actions** → **Build Android APK** → **Run workflow**.
4. When the workflow finishes, open its run and download **Habla-Cards-debug-apk** under Artifacts.
5. Extract the ZIP on your phone and install `app-debug.apk`. Android may ask you to allow installation from that source.

The APK is a debug build for personal testing, not a Play Store release.

## MVP features

- Ukrainian prompt → speak the Spanish word.
- Spanish (Spain) speech recognition.
- Basic answer matching with accent-insensitive comparison.
- Spanish text-to-speech playback.
- Incorrect words are placed into a retry queue.
- Initial vocabulary based on words practised in the user's Spanish lessons.

## Requirements

- JDK 17
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- Android SDK platform 35

## Поведінка кнопки відкладання

Кругла кнопка зі стрілками праворуч від мікрофона показує правильне іспанське слово. Через коротку паузу картка переміщується в кінець поточної черги, а вправа переходить до наступного слова. Неправильна усна відповідь також залишає картку в черзі: після показу правильної відповіді кнопка «Наступне слово» переміщує її в кінець. Правильно вимовлені картки прибираються з черги. Коли всі слова пройдені правильно, показується екран завершення.
