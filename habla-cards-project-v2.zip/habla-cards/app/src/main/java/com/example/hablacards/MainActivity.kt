package com.example.hablacards

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.text.Normalizer
import java.util.Locale

private data class WordCard(val ukrainian: String, val spanish: String, val accepted: List<String> = emptyList())

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val blue = Color.rgb(32, 169, 232)
    private val dark = Color.rgb(65, 65, 65)
    private val cards = listOf(
        WordCard("рано", "temprano"),
        WordCard("молоко", "leche"),
        WordCard("хліб", "pan"),
        WordCard("вода", "agua"),
        WordCard("супермаркет", "supermercado"),
        WordCard("магазин", "tienda"),
        WordCard("туалет", "baño"),
        WordCard("гроші", "dinero"),
        WordCard("картка (банківська)", "tarjeta"),
        WordCard("посилка", "paquete"),
        WordCard("повідомлення", "mensaje"),
        WordCard("сніданок", "desayuno"),
        WordCard("їсти", "comer"),
        WordCard("пити", "beber"),
        WordCard("спати", "dormir"),
        WordCard("ліворуч", "izquierda"),
        WordCard("праворуч", "derecha"),
        WordCard("близько", "cerca"),
        WordCard("ніч", "noche"),
        WordCard("ранок", "mañana")
    )

    private lateinit var wordText: TextView
    private lateinit var instructionText: TextView
    private lateinit var progressText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var micButton: Button
    private lateinit var listenButton: Button
    private lateinit var nextButton: Button
    private lateinit var skipButton: Button
    private lateinit var speechRecognizer: SpeechRecognizer
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var listening = false
    private var answered = false
    private var currentWasCorrect = false
    private val handler = Handler(Looper.getMainLooper())
    private var currentQueue = cards.shuffled().toMutableList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        buildScreen()
        tts = TextToSpeech(this, this)
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            instructionText.text = "На телефоні не знайдено сервіс розпізнавання голосу."
            micButton.isEnabled = false
        } else {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
            speechRecognizer.setRecognitionListener(recognitionListener)
        }
        showCard()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(20), dp(22), dp(18))
            setBackgroundColor(Color.WHITE)
        }
        val header = TextView(this).apply {
            text = "HABLA CARDS"
            textSize = 17f
            letterSpacing = 0.08f
            setTextColor(blue)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        root.addView(header, matchWrap())

        progressText = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(22), 0, dp(8))
        }
        root.addView(progressText, matchWrap())
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = cards.size
            progress = 0
            progressTintList = android.content.res.ColorStateList.valueOf(blue)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.LTGRAY)
        }
        root.addView(progressBar, LinearLayout.LayoutParams(-1, dp(7)))

        val spacer = View(this)
        root.addView(spacer, LinearLayout.LayoutParams(1, 0, 0.7f))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = rounded(Color.WHITE, Color.rgb(228, 228, 228), 2, 28)
            setPadding(dp(18), dp(36), dp(18), dp(36))
            minimumHeight = dp(260)
        }
        wordText = TextView(this).apply {
            textSize = 38f
            setTextColor(dark)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        card.addView(wordText, matchWrap())
        root.addView(card, LinearLayout.LayoutParams(-1, 0, 2.2f))

        instructionText = TextView(this).apply {
            text = "Скажи слово іспанською"
            textSize = 16f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(20), 0, dp(10))
        }
        root.addView(instructionText, matchWrap())

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, 0)
        }
        micButton = Button(this).apply {
            text = "🎙  ГОВОРИТИ"
            textSize = 18f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = rounded(blue, blue, 0, 22)
            setOnClickListener { startListening() }
        }
        val speakRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        speakRow.addView(micButton, LinearLayout.LayoutParams(0, dp(64), 1f))
        skipButton = Button(this).apply {
            text = "🔄"
            textSize = 25f
            isAllCaps = false
            setTextColor(blue)
            background = rounded(Color.WHITE, Color.rgb(228, 228, 228), 2, 22)
            contentDescription = "Показати відповідь і відкласти слово"
            setOnClickListener { revealAndDefer() }
        }
        val skipParams = LinearLayout.LayoutParams(dp(68), dp(64)).apply { leftMargin = dp(12) }
        speakRow.addView(skipButton, skipParams)
        controls.addView(speakRow, matchWrap())

        listenButton = Button(this).apply {
            text = "🔊  Послухати вимову"
            textSize = 15f
            isAllCaps = false
            setTextColor(blue)
            background = rounded(Color.WHITE, Color.LTGRAY, 1, 18)
            setOnClickListener { speakCurrent() }
        }
        val listenParams = LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(10) }
        controls.addView(listenButton, listenParams)

        nextButton = Button(this).apply {
            text = "Наступне слово →"
            textSize = 15f
            isAllCaps = false
            setTextColor(dark)
            background = rounded(Color.rgb(245, 245, 245), Color.rgb(245, 245, 245), 0, 18)
            visibility = View.GONE
            setOnClickListener { moveNext() }
        }
        val nextParams = LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(8) }
        controls.addView(nextButton, nextParams)
        root.addView(controls, matchWrap())

        val bottomSpace = View(this)
        root.addView(bottomSpace, LinearLayout.LayoutParams(1, 0, 0.5f))
        setContentView(root)
    }

    private fun showCard() {
        if (currentQueue.isEmpty()) {
            wordText.text = "¡Muy bien!"
            progressText.text = "Усі слова повторено"
            progressBar.progress = cards.size
            instructionText.text = "Чудова робота! Можеш почати нове коло."
            instructionText.setTextColor(Color.rgb(35, 150, 85))
            micButton.text = "ГОТОВО!"
            micButton.isEnabled = false
            skipButton.isEnabled = false
            listenButton.isEnabled = false
            nextButton.visibility = View.GONE
            answered = true
            return
        }
        val card = currentQueue.first()
        wordText.text = card.ukrainian
        progressText.text = "Залишилося слів: ${currentQueue.size} з ${cards.size}"
        progressBar.progress = cards.size - currentQueue.size
        instructionText.text = "Скажи слово іспанською"
        micButton.text = "🎙  ГОВОРИТИ"
        micButton.isEnabled = true
        listenButton.isEnabled = true
        nextButton.visibility = View.GONE
        skipButton.isEnabled = true
        answered = false
        currentWasCorrect = false
    }

    private fun startListening() {
        if (listening || answered) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
            return
        }
        if (!::speechRecognizer.isInitialized) return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-ES")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "es-ES")
            putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        listening = true
        micButton.text = "СЛУХАЮ…"
        instructionText.text = "Говори чітко іспанською"
        try {
            speechRecognizer.startListening(intent)
        } catch (e: Exception) {
            listening = false
            micButton.text = "🎙  ГОВОРИТИ"
            instructionText.text = "Не вдалося запустити мікрофон. Спробуй ще раз."
        }
    }

    private val recognitionListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() { instructionText.text = "Слухаю…" }
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() { micButton.text = "ОБРОБКА…" }
        override fun onError(error: Int) {
            listening = false
            micButton.text = "🎙  СПРОБУВАТИ ЩЕ"
            instructionText.text = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH -> "Не розібрав відповідь. Спробуй ще раз."
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Проблема з інтернетом або сервісом розпізнавання."
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Потрібен дозвіл на мікрофон."
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Розпізнавання зайняте. Спробуй ще раз."
                else -> "Не вдалося розпізнати. Спробуй ще раз."
            }
        }
        override fun onResults(results: Bundle?) {
            listening = false
            val guesses = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
            checkAnswer(guesses)
        }
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun checkAnswer(guesses: List<String>) {
        val card = currentQueue.first()
        val expected = normalize(card.spanish)
        val match = guesses.firstOrNull { normalize(it) == expected }
        if (match != null) {
            answered = true
            currentWasCorrect = true
            instructionText.text = "✓ Правильно!  ${card.spanish}"
            instructionText.setTextColor(Color.rgb(35, 150, 85))
            micButton.text = "ЧУДОВО!"
            micButton.isEnabled = false
            nextButton.visibility = View.VISIBLE
        } else {
            answered = true
            currentWasCorrect = false
            val heard = guesses.firstOrNull()?.takeIf { it.isNotBlank() }
            instructionText.setTextColor(Color.rgb(205, 85, 65))
            instructionText.text = if (heard != null) "Почув: «$heard». Правильно: ${card.spanish}" else "Не вдалося розпізнати. Правильно: ${card.spanish}"
            micButton.text = "НЕПРАВИЛЬНО"
            micButton.isEnabled = false
            nextButton.visibility = View.VISIBLE
        }
    }

    // Duolingo-style: reveal the answer, then put this card at the end of the queue.
    private fun revealAndDefer() {
        if (answered || currentQueue.isEmpty()) return
        val card = currentQueue.first()
        answered = true
        currentWasCorrect = false
        listening = false
        if (::speechRecognizer.isInitialized) speechRecognizer.cancel()
        wordText.text = card.spanish
        instructionText.setTextColor(Color.rgb(205, 145, 35))
        instructionText.text = "Правильна відповідь"
        micButton.isEnabled = false
        skipButton.isEnabled = false
        listenButton.isEnabled = false
        handler.postDelayed({
            if (!isFinishing && currentQueue.isNotEmpty() && currentQueue.first() == card) {
                moveNext()
            }
        }, 1200)
    }

    private fun moveNext() {
        if (currentQueue.isNotEmpty()) {
            val current = currentQueue.removeAt(0)
            if (!currentWasCorrect) currentQueue.add(current)
        }
        instructionText.setTextColor(Color.GRAY)
        showCard()
    }

    private fun speakCurrent() {
        if (ttsReady && currentQueue.isNotEmpty()) {
            val word = if (answered && wordText.text.toString() == currentQueue.first().spanish) currentQueue.first().spanish else currentQueue.first().spanish
            tts.speak(word, TextToSpeech.QUEUE_FLUSH, null, "spanish_word")
        } else {
            Toast.makeText(this, "Голос ще завантажується", Toast.LENGTH_SHORT).show()
        }
    }

    private fun normalize(value: String): String {
        val noMarks = Normalizer.normalize(value.lowercase(Locale.ROOT).trim(), Normalizer.Form.NFD)
            .replace("\\p{Mn}+".toRegex(), "")
        return noMarks.replace("[^a-zñ ]".toRegex(), "").replace("\\s+".toRegex(), " ").trim()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("es", "ES"))
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startListening()
        else if (requestCode == 100) instructionText.text = "Без дозволу на мікрофон голосова перевірка не працюватиме."
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (::speechRecognizer.isInitialized) speechRecognizer.destroy()
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun rounded(fill: Int, stroke: Int, strokeWidth: Int, radius: Int) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radius).toFloat()
        if (strokeWidth > 0) setStroke(dp(strokeWidth), stroke)
    }
}
